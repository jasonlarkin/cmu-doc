
clear all;
close all;
clc;

disp(' ');
disp('Test of Matlab executable with mex file');
disp(' ');

value = 3.5;

timestwo(value)
